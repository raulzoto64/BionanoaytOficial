<?php
$method = $_SERVER['REQUEST_METHOD'];
$id = $parts[1] ?? null;

if ($method === 'POST' && $id === 'merge') {
    $data = json_decode(file_get_contents('php://input'), true);
    $userId = $data['user_id'] ?? null;
    $guestId = $data['guest_id'] ?? null;
    
    if ($userId && $guestId) {
        // Transferir items del guest al user
        $stmt = $pdo->prepare("UPDATE cart_items SET user_id = ?, guest_id = NULL WHERE guest_id = ?");
        $stmt->execute([$userId, $guestId]);
        echo json_encode(["success" => true]);
    } else {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "Faltan IDs"]);
    }
    exit;
}

if ($method === 'GET' && $id) {
    // JOIN con product_translations para obtener nombre, y prices_by_quantity para precio base
    $stmt = $pdo->prepare("
        SELECT 
            ci.*,
            COALESCE(pt.name, 'Producto') as name,
            p.image as image_url,
            p.slug,
            COALESCE(pbq.price_per_unit, 0) as price
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        LEFT JOIN product_translations pt ON ci.product_id = pt.product_id AND pt.language = 'es'
        LEFT JOIN (
            SELECT product_id, MIN(price_per_unit) as price_per_unit
            FROM prices_by_quantity
            GROUP BY product_id
        ) pbq ON ci.product_id = pbq.product_id
        WHERE ci.guest_id = ? OR ci.user_id = ?
    ");
    $stmt->execute([$id, $id]);
    echo json_encode($stmt->fetchAll());

} else if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $itemId = \Ramsey\Uuid\Uuid::uuid4()->toString();
    $stmt = $pdo->prepare("
        INSERT INTO cart_items (id, guest_id, user_id, product_id, quantity, packaging) 
        VALUES (UUID(), ?, ?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)
    ");
    $stmt->execute([
        $data['guest_id'] ?? null,
        $data['user_id'] ?? null,
        $data['product_id'],
        $data['quantity'],
        $data['packaging'] ?? 'standard'
    ]);
    echo json_encode(["success" => true]);

} else if ($method === 'PUT' && $id) {
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
    $stmt->execute([$data['quantity'], $id]);
    echo json_encode(["success" => true]);

} else if ($method === 'DELETE' && $id) {
    if (strlen($id) > 10) {
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE guest_id = ? OR user_id = ?");
        $stmt->execute([$id, $id]);
    } else {
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE id = ?");
        $stmt->execute([$id]);
    }
    echo json_encode(["success" => true]);

} else {
    // Sin ID: devolver array vacío (no error)
    echo json_encode([]);
}
