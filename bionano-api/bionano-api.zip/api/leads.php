<?php
$method = $_SERVER['REQUEST_METHOD'];
$id = $parts[1] ?? null;

if ($method === 'GET') {
    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM leads WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $row['metadata'] = json_decode($row['metadata'] ?? '{}', true) ?: (object)[];
        }
        echo json_encode($row ?: (object)[]);
    } else {
        $stmt = $pdo->query("SELECT * FROM leads ORDER BY created_at DESC");
        $rows = $stmt->fetchAll();
        foreach ($rows as &$item) {
            $item['metadata'] = json_decode($item['metadata'] ?? '{}', true) ?: (object)[];
        }
        echo json_encode($rows);
    }
} else if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = bin2hex(random_bytes(10));
    $metadata = json_encode($data['metadata'] ?? (object)[]);
    
    $stmt = $pdo->prepare("INSERT INTO leads (id, name, email, phone, message, lead_type, status, visitor_id, user_id, metadata, page_url, referrer, is_anonymous) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $id,
        $data['name'] ?? '',
        $data['email'] ?? '',
        $data['phone'] ?? null,
        $data['message'] ?? null,
        $data['lead_type'] ?? 'website',
        $data['status'] ?? 'new',
        $data['visitor_id'] ?? null,
        $data['user_id'] ?? null,
        $metadata,
        $data['page_url'] ?? '',
        $data['referrer'] ?? '',
        $data['is_anonymous'] ? 1 : 0
    ]);
    echo json_encode(["success" => true, "id" => $id]);

} else if ($method === 'PUT' && $id) {
    $data = json_decode(file_get_contents('php://input'), true);
    // Dinámicamente actualizamos campos presentes
    $fields = [];
    $params = [];
    $allowedFields = ['name', 'last_name', 'email', 'phone', 'status', 'message', 'metadata', 'lead_type', 'page_url', 'referrer'];
    foreach ($allowedFields as $f) {
        if (isset($data[$f])) {
            $fields[] = "$f = ?";
            $params[] = ($f === 'metadata') ? json_encode($data[$f]) : $data[$f];
        }
    }
    
    if (empty($fields)) {
        echo json_encode(["success" => true, "message" => "No fields to update"]);
        exit;
    }
    
    $params[] = $id;
    $stmt = $pdo->prepare("UPDATE leads SET " . implode(", ", $fields) . " WHERE id = ?");
    $stmt->execute($params);
    echo json_encode(["success" => true]);

} else if ($method === 'DELETE' && $id) {
    $stmt = $pdo->prepare("DELETE FROM leads WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true]);
}
